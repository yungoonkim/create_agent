# ADTF 실행용 패키지

소스 기준 커밋: d2ed07695e820d650b422df369610f4fe49e55bc

Windows 탐색기 경로 문제를 줄인 실행 패키지입니다. 과거 시험 원자료·문서는 전체 저장소에 보존하며 이 ZIP에는 넣지 않았습니다. src·예제·잠금파일은 기준 커밋의 원본 그대로입니다. package.json은 과거 원자료/배포도구 검사를 제외한 테스트 명령만 조정했습니다. 전체 저장소 테스트와 실행 패키지 테스트의 범위를 구분하세요.

1. ZIP을 C:\adtf에 풀고 package.json이 있는 adtf-run 폴더에서 PowerShell을 엽니다.
2. npm.cmd ci
3. npm.cmd run eval:review-evidence -- generate --run-live --bundle

3번은 실제 Gemini 유료 요청 최대5회입니다. 기존 PC ADC 인증을 사용하며 로그인 코드/토큰을 전달하지 않습니다. 별도 CALL 입력은 없습니다. RESULT_ARCHIVE의 tar.gz 파일 하나를 전달하세요. 실패하면 generate를 반복하지 말고 기록을 보존하세요.

모델 호출 없는 확인은 npm.cmd test 또는 npm.cmd run eval:review-evidence -- dry-run --bundle 입니다. TEST/STUB은 실제 모델 품질 근거가 아닙니다.

기존 작업 폴더/실행 결과/인증정보를 이 폴더에 복사하지 마세요. 전체 소스와 과거 기록: https://github.com/yungoonkim/create_agent
