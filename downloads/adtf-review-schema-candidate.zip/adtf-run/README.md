# 택배 v2 전송 스키마 단순화 후보

권장 Codex: GPT-6.1 Sol · medium. 결과 파일 전송 전에 설정하세요.

기존 결과 폴더는 보관하고 새 폴더에서 npm.cmd ci를 실행한 뒤 다음을 실행합니다.

npm.cmd run diagnose:review -- --schema-candidate --run-live --bundle

최대1회 유료 가능 요청입니다. 같은 v2의 전송 스키마만 단순화한 후보이며 해결을 보장하지 않습니다. Writer 재작성/원래 기획 변경/정식 Review/자동 승인은 없습니다. 성공/실패 모두 재실행하지 말고 RESULT_ARCHIVE의 tar.gz 하나를 보내주세요.
