# 택배 기획 v2 단일 진단

권장 Codex: GPT-6.1 Sol · medium. 파일 전송 전에 설정하세요.

기존 폴더는 보관하고 이 ZIP을 새 폴더에 풉니다. package.json 폴더에서 다음을 실행합니다.

npm.cmd ci
npm.cmd run diagnose:review -- --run-live --bundle

실패한 v2 재검토 요청만 최대1회 전송합니다. Writer 재작성·원래 프로젝트 변경·공식 Review 저장·자동 승인은 없습니다. 성공/실패 모두 재실행하지 말고 RESULT_ARCHIVE의 tar.gz 하나를 전달하세요. 상세 안내는 examples/reviewer-diagnostic/README.md입니다.
